package Primerapruebaevaluada;

public class Electrodomestico {
	
	//* Constant
	protected final static String colordef = "blanco";
	protected final static char consumoenergeticodef = 'F';
	protected final static double preciobasedef = 100000;
	protected final static double pesodef = 5;
	
	
	//* 
	protected double preciobase;
	protected String color;
	protected char consumoenergetico;
	protected double peso;	
	//* Constructor
		
	public Electrodomestico(){
        this(preciobasedef, pesodef, consumoenergeticodef, colordef);
    }
	
	public Electrodomestico(double precioBase, double peso){
	        this(precioBase, peso, consumoenergeticodef, colordef);
	}
	
	
        public Electrodomestico(double preciobase, String color, char consumoenergetico, double peso) {
		super();
		this.preciobase = preciobase;
		this.color = color;
		this.consumoenergetico = consumoenergetico;
		this.peso = peso;
		comprobarConsumoEnergetico(consumoenergetico);
        comprobarColor(color);
    }
	   
	//* method get and set
	
	public Electrodomestico(double preciobase, double peso, char consumoenergeticodef, String colordef) {
		
	}


	public double getPreciobase() {
		return preciobase;
	}


	public void setPreciobase(double preciobase) {
		this.preciobase = preciobase;
	}


	public String getColor() {
		return color;
	}


	public void setColor(String color) {
		this.color = color;
	}


	public char getConsumoenergetico() {
		return consumoenergetico;
	}


	public void setConsumoenergetico(char consumoenergetico) {
		this.consumoenergetico = consumoenergetico;
	}


	public double getPeso() {
		return peso;
	}


	public void setPeso(double peso) {
		this.peso = peso;
	}


	public static String getColordef() {
		return colordef;
	}


	public static char getConsumoenergeticodef() {
		return consumoenergeticodef;
	}


	public static double getPreciobasedef() {
		return preciobasedef;
	}


	public static double getPesodef() {
		return pesodef;
	}

	//* methods: 
	
	public void comprobarConsumoEnergetico(char letra) {
		if (letra == 'A'|| letra == 'B'|| letra == 'C'|| letra =='D'|| letra == 'E'|| letra == 'F' ) {
			this.consumoenergetico= letra;
		} else {
			this.consumoenergetico = consumoenergeticodef;
		}
	
	}
	
	public void comprobarColor(String color) {
		if(color=="negro"|| color=="rojo"|| color=="azul"||color=="gris") {
			this.color= color;
		} else {
			this.color=colordef;
		}
		
	}
		
	
	public double precioFinal() {
		double adicional=0;
		
		switch(consumoenergetico) {
		case 'A':
			adicional += 85000;
		break;
		
		case 'B':
			adicional += 70000;
		break;
		case'D':
			adicional += 50000;
		break;
		case'E':
			adicional += 40000;
		break;
		case 'F':
			adicional += 8500;
		break;
		default:
			
		} 
		if (peso >= 0 && peso <=19) {
			adicional += 8500;
		} else if( peso >=20 && peso <= 49) {
			adicional += 40000;
		}else if (peso >= 50 && peso <= 79) {
			adicional += 70000;
		}else if (peso >= 80) {
			adicional += 85000;
		}
		return preciobase + adicional;
		
	}

	
	
	
	
	
	
	

	
	
	
	
	


}
