package Primerapruebaevaluada;

public class Televisor extends Electrodomestico {

	//*atributos
	protected final static int resoluciondef = 20;
	protected final static boolean sintonizadortdtdef = false;
	private int resolucion;
	private boolean sintonizadortdt;
	
	//* constructores
	public Televisor(){
        this(preciobasedef, pesodef, consumoenergeticodef, colordef, resoluciondef, sintonizadortdtdef);
    }
	
	public Televisor(double preciobase, double peso){
        this(preciobase, peso, consumoenergeticodef, colordef, resoluciondef, sintonizadortdtdef);
    }
	
	 public Televisor(double preciobase, double peso, char consumoenergetico, String color, int resolucion, boolean sintonizadortdt){
	        super(preciobase, peso, consumoenergetico, color);
	        this.resolucion=resolucion;
	        this.sintonizadortdt=sintonizadortdt;
	}
		
	//* metodos get and set	
	public int getResolucion() {
		return resolucion;
	}
	public void setResolucion(int resolucion) {
		this.resolucion = resolucion;
	}
	public boolean isSintonizadortdt() {
		return sintonizadortdt;
	}
	public void setSintonizadortdt(boolean sintonizadortdt) {
		this.sintonizadortdt = sintonizadortdt;
	}
	public static int getResoluciondef() {
		return resoluciondef;
	}
	public static boolean isSintonizadortdtdef() {
		return sintonizadortdtdef;
	}


	public double precioFinal() {
		double adicional = super.precioFinal();
		if (resolucion >40) {
			adicional += preciobase*0.3;
		}
		return adicional;
		
}
		
}
	

	
	
	
	

	
	
	


