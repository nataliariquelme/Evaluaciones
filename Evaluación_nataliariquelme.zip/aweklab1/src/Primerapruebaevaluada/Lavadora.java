package Primerapruebaevaluada;

public class Lavadora extends Electrodomestico{
	
	//*Constante
	
	protected final static int cargadef = 5;
	//** Atributo
	
	private int carga;
	
	//*constructores
	 public Lavadora(){
	        this(preciobasedef, pesodef, consumoenergeticodef, colordef, cargadef);
	 }
	 public Lavadora(double preciobase, double peso){
	        this(preciobase, peso, consumoenergeticodef, colordef, cargadef);
	 }
	 public Lavadora(double preciobase, double peso, char consumoenergetico, String color, int carga){
	        super(preciobase,peso, consumoenergetico,color);
	        this.carga=carga;
	 }


	//*metodos get and set
	
	public int getCarga() {
		return carga;
	}
	
	public void setCarga(int carga) {
		this.carga = carga;
	}
	
	public double precioFinal() {
		double adicional = super.precioFinal();
		if (carga >30) {
			adicional += 40000;	
		}
		return adicional;
		
}
		
	
	

	
	
	
	


	
		
	

	
	
	
	

	
}
	


		
	


