package Primerapruebaevaluada;

import javax.swing.JOptionPane;

public class Principal {
	
	    public static void main(String[] args) {
	  
	        //****Creaci�n del array de Electrodomesticos
	        Electrodomestico listaElectrodomesticos[]=new Electrodomestico[10];
	  
	        listaElectrodomesticos[0]=new Electrodomestico(300000, "rojo", 'A', 30);
	        listaElectrodomesticos[1]=new Lavadora(200000, 20);
	        listaElectrodomesticos[2]=new Televisor(30000, 10, 'B', "gris", 30, true);
	        listaElectrodomesticos[3]=new Electrodomestico();
	        listaElectrodomesticos[4]=new Electrodomestico(500000, "negro", 'C', 20);
	        listaElectrodomesticos[5]=new Lavadora(30000, 40, 'B', "azul", 40);
	        listaElectrodomesticos[6]=new Televisor(50000, 15);
	        listaElectrodomesticos[7]=new Lavadora(40000, 45, 'F', "rojo", 10);
	        listaElectrodomesticos[8]=new Televisor(40000, 20, 'D', "negro", 50, false);
	        listaElectrodomesticos[9]=new Electrodomestico(300000, 30);
	  
	        //****Suma de precios
	        double sumaElectrodomesticos=0;
	        double sumaTelevisiones=0;
	        double sumaLavadoras=0;
	  
	        //Recorrer el array/m�todo precioFinal
	        for(int i=0;i<listaElectrodomesticos.length;i++){
	         
	  
	            if(listaElectrodomesticos[i] instanceof Electrodomestico){
	                sumaElectrodomesticos+=listaElectrodomesticos[i].precioFinal();
	            }
	            if(listaElectrodomesticos[i] instanceof Lavadora){
	                sumaLavadoras+=listaElectrodomesticos[i].precioFinal();
	            }
	            if(listaElectrodomesticos[i] instanceof Televisor){
	                sumaTelevisiones+=listaElectrodomesticos[i].precioFinal();
	            }
	        }
	  
	        //Mostramos los resultados
	        JOptionPane.showMessageDialog(null, "Bienvenido a la tienda de electrodom�sticos");
	        JOptionPane.showMessageDialog(null, "La suma final del precio de los electrodom�sticos es de $"+sumaElectrodomesticos);
	        JOptionPane.showMessageDialog(null, "La suma final del precio de las lavadoras es de $"+sumaLavadoras);
	        JOptionPane.showMessageDialog(null, "La suma final del precio de los televisores $"+sumaTelevisiones);
	        JOptionPane.showMessageDialog(null, "Gracias por visitarnos");
	  
	    }
	  
	}
