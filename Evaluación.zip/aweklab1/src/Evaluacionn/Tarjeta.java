package Evaluacionn;


public class Tarjeta {
	
	// atributos
	private int numero;
	private int saldo;
	private String tipo;
	private String estado;
	private int dias;
	// constructor
	public Tarjeta(int Numero, int Saldo, String Tipo, String Estado, int dias) {
		this.numero = Numero;
		this.saldo = Saldo;
		this.tipo = Tipo;
		this.estado = Estado;
	// metodos
	
	
	}
	public void cargar(int Saldo) {
		if(Saldo>0)
			this.saldo += Saldo;
		 System.out.println("La tarjeta n�mero: "+ numero + " de tipo: "+ tipo + " tiene un saldo de: "+ saldo+ ". La tarjeta se encuentra " + estado+"." );
	}
    
	 public void pagonormal (int Saldo) {
		 int pasajenormal= 600;
		 this.saldo-=pasajenormal;
		 System.out.println("La tarjeta n�mero: "+ numero + " de tipo: "+ tipo + " tiene un saldo de: "+ saldo+ ". La tarjeta se encuentra " + estado + ".");
	 }
	 public void pagotne (int Saldo) {
		 int pasajetne = 200;
		 this.saldo-= pasajetne;
		 System.out.println("La tarjeta n�mero: "+ numero + " de tipo: "+ tipo + " tiene un saldo de: "+ saldo+ ". La tarjeta se encuentra " + estado + ".");
	 }
	 public void pagobip (int Saldo) {
		 int pasajebip = 400;
		 this.saldo-= pasajebip;
		    System.out.println("La tarjeta n�mero: "+ numero + " de tipo: "+ tipo + " tiene un saldo de: "+ saldo+ ". La tarjeta se encuentra " + estado +".");
	 }   

}
	


