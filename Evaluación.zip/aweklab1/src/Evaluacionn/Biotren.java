package Evaluacionn;

public class Biotren {
	public static void main(String[]args) {
		
		Tarjeta tarjetanormal= new Tarjeta(1234,750,"Com�n","Activa", 0);
		Tarjeta tarjetatne = new Tarjeta(5678,750,"TNE", "Activa", 0);
		Tarjeta tarjetaconvenio = new Tarjeta(91011,750,"Bip", "Activa", 0);
// Ingreso de dinero en Tarjeta:
        tarjetanormal.cargar(2000);
  
        tarjetatne.cargar(1000);
      
        tarjetaconvenio.cargar(3000);
		
//Pago de pasaje en la tarjeta:
		tarjetanormal.pagonormal(600);

		tarjetatne.pagotne(200);

		tarjetaconvenio.pagobip(400);

	}
	
}
