package Evaluaacio4;

public class eprivado {
	public static void main(String[]args) {
		Privado eprivado = new Privado("123456787", "Francisco", "Risopatr�n", "De Lourdes", "Juan Bosco 1786", 976834616, 6000000, "Comuna de Las Condes", "Genrencia");

	}
	
	}
	
	


