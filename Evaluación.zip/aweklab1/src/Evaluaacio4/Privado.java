package Evaluaacio4;

public class Privado extends Empleado{
	private String comuna;
	private String empresa;

	public Privado(String rut, String nombre, String apellidop, String apellidom, String direccion, int telefono,
			double sueldo, String comuna, String empresa) {
		super(rut, nombre, apellidop, apellidom, direccion, telefono, sueldo);
	System.out.println("Rut: "+ rut+"/ Nombre: "+nombre+"/ Apellido Paterno: " +apellidop+"/ Apellido Materno: "+ apellidom+ "/ Direcci�n: "+ direccion+ "/ Tel�fono: "+telefono+ "/ Sueldo: "+sueldo+ "/ Comuna: "+comuna+"/ Empresa: "+ empresa);
		
	}
	
}
