package Evaluaacio4;

public class Publico extends Empleado {
	private String municipalidad;
	private String departamento;

	public Publico(String rut, String nombre, String apellidop, String apellidom, String direccion, int telefono,
			double sueldo, String municipalidad, String departamento) {
		super(rut, nombre, apellidop, apellidom, direccion, telefono, sueldo);
		System.out.println("Rut: "+ rut+"/ Nombre: "+nombre+"/ Apellido Paterno :" +apellidop+"/ Apellido Materno : "+ apellidom+ "/ Direcci�n: "+ direccion+ "/ Tel�fono: "+telefono+ "/ Sueldo: "+sueldo+ "/ Municipalidad: "+municipalidad+"/ Departamento :"+ departamento);
	
	}


	}
	
	


