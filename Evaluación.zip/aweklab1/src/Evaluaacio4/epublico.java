package Evaluaacio4;

public class epublico {
	public static void main(String[]args) {
	Publico epublico = new Publico("152423566", "Fernando","Mellado", "Salinas", "Los Laureles 45", 945281947, 780000, "Municipalidad de los Alamos", "Administrativo");
	
	}

}
