package Evaluaacio3;

	public class auto  {
		public static void main(String[]args) {
			automovil autonuevo = new automovil("Audi", "Sportback", 2019, 300) ;
		
	autonuevo.Preciofinal();
			
		}
	}


