package Evaluaacio3;

public class automovil {
		private String marca;
		private String modelo;
		private int a�o;
		private double precio;
		public automovil(String marca, String modelo, int a�o, double precio) {
			super();
			this.marca = marca;
			this.modelo = modelo;
			this.a�o = a�o;
			this.precio = precio;
		}
		public String getMarca() {
			return marca;
		}
		public void setMarca(String marca) {
			this.marca = marca;
		}
		public String getModelo() {
			return modelo;
		}
		public void setModelo(String modelo) {
			this.modelo = modelo;
		}
		public int getA�o() {
			return a�o;
		}
		public void setA�o(int a�o) {
			this.a�o = a�o;
		}
		public double getPrecio() {
			return precio;
		}
		public void setPrecio(double precio) {
			this.precio = precio;
		}
		
		public void Preciofinal() {
		
			double preciofinal = (precio) + (precio*0.19) + (precio*0.5);
			System.out.println("El auto marca "+ marca + " modelo "+ modelo+ " del a�o "+ a�o+ " tiene un valor final de: $"+ preciofinal);
			
			
		}

	}
		

